import React from 'react';
import CurrencyConverterScreen from './src/views/CurrencyConverterScreen';

export default function App() {
  return <CurrencyConverterScreen />;
}