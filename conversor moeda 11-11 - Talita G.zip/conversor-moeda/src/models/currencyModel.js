const BASE_URL = 'https://api.frankfurter.dev/v2';

/**
 * Responsável pela comunicação com a API Frankfurter.
 */
export const currencyModel = {
  /**
   * Busca as moedas disponíveis.
   */
  async fetchCurrencies() {
    try {
      const response = await fetch(`${BASE_URL}/currencies`);
      if (!response.ok) {
        throw new Error(`Erro na requisição das moedas (Status: ${response.status})`);
      }
      const data = await response.json();
      
      const currenciesMap = {};
      if (Array.isArray(data)) {
        data.forEach(item => {
          currenciesMap[item.iso_code] = item.name;
        });
      }
      return currenciesMap;
    } catch (error) {
      throw new Error('Não foi possível carregar a lista de moedas. Verifique sua conexão.');
    }
  },

  /**
   * Consulta a taxa de câmbio entre duas moedas.
   * @param {string} from - Código da moeda de origem (ex: 'BRL')
   * @param {string} to - Código da moeda de destino (ex: 'LBP')
   */
  async fetchExchangeRate(from, to) {
    try {
      const response = await fetch(`${BASE_URL}/rate/${from}/${to}`);
      if (!response.ok) {
        throw new Error(`Erro ao obter taxa de câmbio (Status: ${response.status})`);
      }
      const data = await response.json();
      
      
      const rate = data.rate;
      
      if (rate === undefined || rate === null) {
        throw new Error('Taxa de câmbio não encontrada na resposta da API.');
      }

      return {
        rate: Number(rate),
        date: data.date || 'Data não informada',
      };
    } catch (error) {
      throw new Error(error.message || 'Falha ao consultar a taxa de câmbio.');
    }
  },
};