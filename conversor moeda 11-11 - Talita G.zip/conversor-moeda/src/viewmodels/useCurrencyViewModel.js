import { useState, useEffect, useCallback } from 'react';
import { currencyModel } from '../models/currencyModel';

export function useCurrencyViewModel() {
  const [currencies, setCurrencies] = useState({});
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('BRL');
  const [amount, setAmount] = useState('100');
  
  const [convertedAmount, setConvertedAmount] = useState(null);
  const [exchangeRate, setExchangeRate] = useState(null);
  const [rateDate, setRateDate] = useState(null);
  const [lastSearchInfo, setLastSearchInfo] = useState(null);

  const [isLoadingCurrencies, setIsLoadingCurrencies] = useState(true);
  const [isConverting, setIsConverting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Carrega as moedas na inicialização
  const loadCurrencies = useCallback(async () => {
    setIsLoadingCurrencies(true);
    setErrorMessage('');
    try {
      const data = await currencyModel.fetchCurrencies();
      setCurrencies(data);
      
      // Garante moedas iniciais válidas se estiverem na lista
      const keys = Object.keys(data);
      if (keys.length > 0) {
        if (!keys.includes('USD')) setFromCurrency(keys[0]);
        if (!keys.includes('BRL')) setToCurrency(keys[1] || keys[0]);
      }
    } catch (err) {
      setErrorMessage(err.message);
    } finally {
      setIsLoadingCurrencies(false);
    }
  }, []);

  useEffect(() => {
    loadCurrencies();
  }, [loadCurrencies]);

  // Função para inverter moedas
  const swapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
    setConvertedAmount(null);
  };

  // Validação dos dados 
  const validateInputs = () => {
    if (!amount || amount.trim() === '') {
      return 'Por favor, informe um valor para converter.';
    }

    // Trata vírgula e ponto para aceitar entradas no padrão brasileiro (10,50 -> 10.50)
    const normalizedAmount = amount.replace(',', '.');
    const parsedAmount = parseFloat(normalizedAmount);

    if (isNaN(parsedAmount)) {
      return 'Digite um valor numérico válido.';
    }

    if (parsedAmount <= 0) {
      return 'O valor digitado deve ser maior que zero.';
    }

    if (!fromCurrency || !toCurrency) {
      return 'Selecione as moedas de origem e destino.';
    }

    if (fromCurrency === toCurrency) {
      return 'As moedas de origem e destino devem ser diferentes.';
    }

    return null;
  };

  // Processo de conversão
  const convertCurrency = async () => {
    setErrorMessage('');
    const validationError = validateInputs();

    if (validationError) {
      setErrorMessage(validationError);
      return;
    }

    setIsConverting(true);

    try {
      const normalizedAmount = parseFloat(amount.replace(',', '.'));
      const { rate, date } = await currencyModel.fetchExchangeRate(fromCurrency, toCurrency);
      
      const result = normalizedAmount * rate;

      setExchangeRate(rate);
      setRateDate(date);
      setConvertedAmount(result);
      setLastSearchInfo({
        originalAmount: normalizedAmount,
        from: fromCurrency,
        to: toCurrency,
      });
    } catch (err) {
      setErrorMessage(err.message);
      // Limpa resultado anterior em caso de erro 
      setConvertedAmount(null);
    } finally {
      setIsConverting(false);
    }
  };

  return {
    currencies,
    fromCurrency,
    setFromCurrency,
    toCurrency,
    setToCurrency,
    amount,
    setAmount,
    convertedAmount,
    exchangeRate,
    rateDate,
    lastSearchInfo,
    isLoadingCurrencies,
    isConverting,
    errorMessage,
    loadCurrencies,
    swapCurrencies,
    convertCurrency,
  };
}