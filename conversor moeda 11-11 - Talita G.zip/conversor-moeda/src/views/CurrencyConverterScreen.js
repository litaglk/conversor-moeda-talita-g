import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  SafeAreaView,
  StatusBar,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useCurrencyViewModel } from '../viewmodels/useCurrencyViewModel';

export default function CurrencyConverterScreen() {
  const {
    currencies,
    fromCurrency,
    setFromCurrency,
    toCurrency,
    setToCurrency,
    amount,
    setAmount,
    convertedAmount,
    exchangeRate,
    rateDate,
    lastSearchInfo,
    isLoadingCurrencies,
    isConverting,
    errorMessage,
    loadCurrencies,
    swapCurrencies,
    convertCurrency,
  } = useCurrencyViewModel();

  const currencyKeys = Object.keys(currencies);

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#f4f6f9" />
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        
        {/* Cabeçalho */}
        <View style={styles.header}>
          <Text style={styles.title}>Conversor de Moedas</Text>
          <Text style={styles.subtitle}>Taxas em tempo real via API Frankfurter</Text>
        </View>

        {/* Mensagem de Erro Geral/Validação */}
        {errorMessage ? (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>{errorMessage}</Text>
            {isLoadingCurrencies && (
              <TouchableOpacity style={styles.retryButton} onPress={loadCurrencies}>
                <Text style={styles.retryButtonText}>Tentar Novamente</Text>
              </TouchableOpacity>
            )}
          </View>
        ) : null}

        {/* Formuário principal */}
        <View style={styles.card}>
          <Text style={styles.label}>Valor a Converter</Text>
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            placeholder="Ex: 100,00"
            value={amount}
            onChangeText={setAmount}
            editable={!isConverting}
          />

          {/* Seleção de Moedas */}
          <View style={styles.selectionRow}>
            <View style={styles.pickerContainer}>
              <Text style={styles.label}>Origem</Text>
              <View style={styles.pickerWrapper}>
                <Picker
                  selectedValue={fromCurrency}
                  onValueChange={(itemValue) => setFromCurrency(itemValue)}
                  enabled={!isLoadingCurrencies && !isConverting}
                >
                  {currencyKeys.map((code) => (
                    <Picker.Item key={code} label={`${code} - ${currencies[code]}`} value={code} />
                  ))}
                </Picker>
              </View>
            </View>

            <TouchableOpacity
              style={styles.swapButton}
              onPress={swapCurrencies}
              disabled={isLoadingCurrencies || isConverting}
            >
              <Text style={styles.swapButtonText}>⇄</Text>
            </TouchableOpacity>

            <View style={styles.pickerContainer}>
              <Text style={styles.label}>Destino</Text>
              <View style={styles.pickerWrapper}>
                <Picker
                  selectedValue={toCurrency}
                  onValueChange={(itemValue) => setToCurrency(itemValue)}
                  enabled={!isLoadingCurrencies && !isConverting}
                >
                  {currencyKeys.map((code) => (
                    <Picker.Item key={code} label={`${code} - ${currencies[code]}`} value={code} />
                  ))}
                </Picker>
              </View>
            </View>
          </View>

          {/* Botão de Conversão */}
          <TouchableOpacity
            style={[styles.convertButton, isConverting && styles.buttonDisabled]}
            onPress={convertCurrency}
            disabled={isConverting || isLoadingCurrencies}
          >
            {isConverting ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.convertButtonText}>Converter</Text>
            )}
          </TouchableOpacity>
        </View>

        {/* Exibição dos Resultados */}
        {convertedAmount !== null && lastSearchInfo && (
          <View style={styles.resultCard}>
            <Text style={styles.resultTitle}>Resultado da Conversão</Text>
            
            <Text style={styles.resultMainText}>
              {lastSearchInfo.originalAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} {lastSearchInfo.from} =
            </Text>
            <Text style={styles.resultConvertedText}>
              {convertedAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} {lastSearchInfo.to}
            </Text>

            <View style={styles.divider} />

            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Taxa Utilizada:</Text>
              <Text style={styles.infoValue}>1 {lastSearchInfo.from} = {exchangeRate} {lastSearchInfo.to}</Text>
            </View>

            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Data de Referência:</Text>
              <Text style={styles.infoValue}>{rateDate}</Text>
            </View>

            <Text style={styles.disclaimerText}>
              * Taxa de referência fornecida pela API Frankfurter (não cotação comercial instantânea).
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#d81c22',
  },
  container: {
    padding: 20,
  },
  header: {
    marginBottom: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  subtitle: {
    fontSize: 14,
    color: '##FFFFFF',
    marginTop: 4,
  },
  card: {
    backgroundColor: '#00A651',
    borderRadius: 12,
    padding: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#cbd5e0',
    borderRadius: 8,
    padding: 12,
    fontSize: 18,
    backgroundColor: '#FFFFFF',
    marginBottom: 16,
  },
  selectionRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  pickerContainer: {
    flex: 1,
  },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: '#cbd5e0',
    borderRadius: 8,
    backgroundColor: '#f8fafc',
    overflow: 'hidden',
  },
  swapButton: {
    backgroundColor: '#e2e8f0',
    padding: 10,
    borderRadius: 8,
    marginHorizontal: 8,
    marginBottom: 4,
  },
  swapButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#D81C22',
  },
  convertButton: {
    backgroundColor: '#D81C22',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonDisabled: {
    backgroundColor: '#a0aec0',
  },
  convertButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  errorContainer: {
    backgroundColor: '#fff5f5',
    borderColor: '#feb2b2',
    borderWidth: 1,
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  errorText: {
    color: '#c53030',
    fontSize: 14,
    textAlign: 'center',
  },
  retryButton: {
    marginTop: 8,
    alignSelf: 'center',
  },
  retryButtonText: {
    color: '#2b6cb0',
    fontWeight: 'bold',
  },
  resultCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginTop: 20,
    borderLeftWidth: 4,
    borderLeftColor: '#38a169',
    elevation: 3,
  },
  resultTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2d3748',
    marginBottom: 8,
  },
  resultMainText: {
    fontSize: 16,
    color: '#718096',
  },
  resultConvertedText: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#276749',
    marginVertical: 4,
  },
  divider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 12,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  infoLabel: {
    color: '#718096',
    fontSize: 14,
  },
  infoValue: {
    color: '#2d3748',
    fontWeight: '600',
    fontSize: 14,
  },
  disclaimerText: {
    fontSize: 11,
    color: '#a0aec0',
    fontStyle: 'italic',
    marginTop: 10,
    textAlign: 'center',
  },
});